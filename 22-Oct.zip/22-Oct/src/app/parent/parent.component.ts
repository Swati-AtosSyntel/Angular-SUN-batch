import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-parent',
  templateUrl: './parent.component.html',
  styleUrls: ['./parent.component.css']
})
export class ParentComponent implements OnInit {
num=0;
thankYouText="";
sendToChild(){
  this.num++;
}
  constructor() { }

  ngOnInit(): void {
  }
receiveThanks(event:any){
  this.thankYouText=event;
  console.log(this.thankYouText);
}
}
