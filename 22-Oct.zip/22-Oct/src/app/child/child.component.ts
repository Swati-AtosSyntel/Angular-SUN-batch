import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';

@Component({
  selector: 'app-child',
  templateUrl: './child.component.html',
  styleUrls: ['./child.component.css']
})
export class ChildComponent implements OnInit {
 @Input()
numreceived:any;

  constructor() { }

  ngOnInit(): void {
  }
  @Output()
  thanksMessage=new EventEmitter();

  sayThanks(){
    this.thanksMessage.emit("Thanks for sharing number!!!!");
  }

}
