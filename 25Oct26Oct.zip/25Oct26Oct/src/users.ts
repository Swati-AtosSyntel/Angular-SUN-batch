export class users{
    
    id:number=0;
    name:string="";


}