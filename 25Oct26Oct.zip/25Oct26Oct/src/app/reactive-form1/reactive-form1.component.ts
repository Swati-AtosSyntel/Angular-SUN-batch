import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';

@Component({
  selector: 'app-reactive-form1',
  templateUrl: './reactive-form1.component.html',
  styleUrls: ['./reactive-form1.component.css']
})
export class ReactiveForm1Component implements OnInit {
loginform:any;
  constructor(private formbuilder:FormBuilder) { }

  ngOnInit(): void {
this.loginform=this.formbuilder.group({
  emailid:[Validators.required],
  password:[Validators.required],
  address:this.formbuilder.group({
    
  })
})
  }

}
