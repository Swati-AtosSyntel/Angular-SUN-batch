import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';
import {HttpClientModule} from '@angular/common/http';
import {ReactiveFormsModule} from '@angular/forms'
import {Routes,RouterModule} from '@angular/router';
import { AppComponent } from './app.component';
import { BasicComponent } from './basic/basic.component';
import { EmployeelistComponent } from './employeelist/employeelist.component';
import { GenderPipe } from './gender.pipe';
import { ParentComponent } from './parent/parent.component';
import { ChildComponent } from './child/child.component';
import { EmployeecountComponent } from './employeecount/employeecount.component';
import { UsersListComponent } from './users-list/users-list.component';
import { TemplateformComponent } from './templateform/templateform.component';
import { ReactiveformComponent } from './reactiveform/reactiveform.component';
import { PagenotfoundComponent } from './pagenotfound/pagenotfound.component';
import { HomeComponent } from './home/home.component';
const routes:Routes=[
  {path:'home',component:HomeComponent},
  {path:'employee',component:EmployeelistComponent},
  {path:'users',component:UsersListComponent},
  {path:'basic',component:BasicComponent},
  {path:'template',component:TemplateformComponent},
  {path:'reactive',component:ReactiveformComponent},
  {path:'',redirectTo:'/home',pathMatch:'full'},
  {path:'**',component:PagenotfoundComponent}
]
@NgModule({
  declarations: [
    AppComponent,
    BasicComponent,
    EmployeelistComponent,
    GenderPipe,
    ParentComponent,
    ChildComponent,
    EmployeecountComponent,
    UsersListComponent,
    TemplateformComponent,
    ReactiveformComponent,
    PagenotfoundComponent
  ],
  imports: [
    BrowserModule,FormsModule,HttpClientModule,ReactiveFormsModule,RouterModule.forRoot(routes)
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
