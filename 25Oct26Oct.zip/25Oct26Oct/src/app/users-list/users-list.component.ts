import { Component, OnInit } from '@angular/core';
import { users } from 'src/users';
import { UsersService } from '../users.service';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-users-list',
  templateUrl: './users-list.component.html',
  styleUrls: ['./users-list.component.css']
})
export class UsersListComponent implements OnInit {

  userdetails:users[]=[];
  // constructor(private userService:UsersService) { 
  //   this.userdetails=userService.getUsers();
  //   console.log(this.userdetails);
  // }
  constructor(private http:HttpClient){

  }

  ngOnInit(): void {
   this.getUsers();
  }
  getUsers(){
    this.http.get<users[]>("https://jsonplaceholder.typicode.com/users")
     .subscribe((data)=>{
       this.userdetails=data;
       console.log(this.userdetails);
     },
     (error)=>{
       console.error("Request failed");
     },
     ()=>{
       console.log("Request completed");
     })
}
}
