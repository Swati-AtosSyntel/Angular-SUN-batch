import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import { users } from 'src/users';
@Injectable({
  providedIn: 'root'
})
export class UsersService {

  users:users[]=[];
  constructor(private http:HttpClient) {

   }
   getUsers(){
    this.http.get<users[]>("https://jsonplaceholder.typicode.com/users")
     .subscribe((data)=>{
       this.users=data;
       console.log(this.users);
     },
     (error)=>{
       console.error("Request failed");
     },
     ()=>{
       console.log("Request completed");
     })
      return this.users;
   }
}
