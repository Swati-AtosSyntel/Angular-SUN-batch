import { AbstractControl, ValidationErrors } from "@angular/forms";

export function passwordValidation(control:AbstractControl):ValidationErrors|null{
    if(control.value.length<8)
    {
        return {"passwordValidation":true};
    }
    return null;
}