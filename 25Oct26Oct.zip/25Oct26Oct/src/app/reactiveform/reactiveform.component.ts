import { Component, OnInit } from '@angular/core';
import { FormGroup,FormControl, Validators } from '@angular/forms';
import {passwordValidation} from './passwordValidation.validator';
@Component({
  selector: 'app-reactiveform',
  templateUrl: './reactiveform.component.html',
  styleUrls: ['./reactiveform.component.css']
})
export class ReactiveformComponent implements OnInit {
formdata:any;
emailID:any;
selectedCountry:any;
  constructor() { }

  ngOnInit(): void {
    this.formdata=new FormGroup({
      firstName:new FormControl(null,[Validators.required,Validators.minLength(4),Validators.maxLength(7)]),
      emailID:new FormControl("swati.bhirud@atos.net",Validators.pattern('[^@]*@[^@]*')),
      address:new FormGroup({
        country:new FormControl(),
        city:new FormControl(),
        postalcode:new FormControl(null,Validators.pattern('^[1-9][0-9]{4}$'))
      }),
      password:new FormControl("abc@123",[Validators.required,passwordValidation])
    });
  }
  // passwordValidation(formcontrol:any):any{
  //   if(formcontrol.value.length<8){
  //     return{"password":true};
  //   }
 // }
onSubmit(data:any){
    this.emailID=data.emailID;
    this.selectedCountry=data.address.country;
    

}
}
