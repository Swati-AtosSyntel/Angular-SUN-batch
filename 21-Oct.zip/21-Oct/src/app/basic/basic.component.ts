import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-basic',
  templateUrl: './basic.component.html',
  //template:`<h1><p>basic works!
 // </p></h1>`,
  styleUrls: ['./basic.component.css']
})
export class BasicComponent implements OnInit {

  fname:any="Swati";
  colors=['Blue','Green','Red','Orange'];
  show=true;
  month=1;
  min=1;
  max=12;
isSelected=true;
  constructor() { }

  ngOnInit(): void {
  }
updateName(){
  this.fname="Susan";
}
}
